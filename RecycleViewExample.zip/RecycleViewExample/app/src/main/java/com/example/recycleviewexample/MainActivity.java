package com.example.recycleviewexample;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    RecyclerView.Adapter myAdapter;
    RecyclerView.LayoutManager layoutManager;
    ArrayList<Person> people;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.list);
        recyclerView.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        people = new ArrayList<Person>();
        people.add(new Person("hello","welcome","Bus"));
        people.add(new Person("hello1","welcome1","Plane"));
        people.add(new Person("hello2","welcome2","Bus"));
        people.add(new Person("hello3","welcome3","Plane"));
        people.add(new Person("hello4","welcome4","Bus"));
        people.add(new Person("hello5","welcome5","Bus"));
        people.add(new Person("hello6","welcome6","Bus"));
        people.add(new Person("hello7","welcome7","Plane"));
        people.add(new Person("hello8","welcome8","Bus"));
        people.add(new Person("hello9","welcome9","Bus"));
        people.add(new Person("hello10","welcome10","Bus"));
        people.add(new Person("hello11","welcome11","Bus"));
        people.add(new Person("hello12","welcome12","Plane"));
        people.add(new Person("hello13","welcome13","Bus"));
        people.add(new Person("hello14","welcome14","Bus"));
        people.add(new Person("hello18","welcome15","Plane"));
        people.add(new Person("hello19","welcome16","Bus"));
        myAdapter= new PersonAdapter(this.people);
        recyclerView.setAdapter(myAdapter);
    }
}
