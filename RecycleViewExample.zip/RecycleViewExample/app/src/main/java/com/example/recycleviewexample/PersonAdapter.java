package com.example.recycleviewexample;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PersonAdapter extends RecyclerView.Adapter<PersonAdapter.ViewHolder> {
    @NonNull
    @Override
    public PersonAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item,parent);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull PersonAdapter.ViewHolder holder, final int position) {
        holder.fname.setText(people.get(position).getFname());
        holder.lname.setText(people.get(position).getLname());
        if(people.get(position).getPref().equals("Bus")){
            holder.image.setImageResource(R.drawable.bus);
        }
        else {
            holder.image.setImageResource(R.drawable.plane);
        }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(v.getContext(),""+position,Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return people.size();
    }
    private ArrayList<Person> people;
    public PersonAdapter(ArrayList<Person>list){
        people=list;
    }
    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView fname,lname;
        ImageView image;

        public ViewHolder(@NonNull View itemView, TextView fname, TextView lname, ImageView image) {
            super(itemView);
            image=itemView.findViewById(R.id.img);
            fname=itemView.findViewById(R.id.fname);
            lname=itemView.findViewById(R.id.lname);
        }

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
