package com.example.fragmenttest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements List.ItemSelected {

    TextView tvDescription;
    ArrayList<String> description = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvDescription = findViewById(R.id.tvDescription);
        description.add("This is Description 1");
        description.add("This is Description 2");
        description.add("This is Description 3");

    }

    @Override
    public void onItemSelected(int index) {
        tvDescription.setText(description.get(index));
    }
}
