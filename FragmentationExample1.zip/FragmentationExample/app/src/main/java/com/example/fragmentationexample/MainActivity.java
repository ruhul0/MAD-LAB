package com.example.fragmentationexample;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.ListFragment;

import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements ListFrag.Itemslected {
    TextView tvdescription;
    String[]discription;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvdescription = findViewById(R.id.tvdescription);


        discription=getResources().getStringArray(R.array.descriptions);

        if (findViewById(R.id.portrait)!=null){
            FragmentManager manager = this.getSupportFragmentManager();
            manager.beginTransaction()
                    .show(manager.findFragmentById(R.id.fragment))
                    .hide(manager.findFragmentById(R.id.fragment2))
                    .commit();
        }
        if (findViewById(R.id.landscape)!=null){
            FragmentManager manager = this.getSupportFragmentManager();
            manager.beginTransaction()
                    .show(manager.findFragmentById(R.id.fragment))
                    .show(manager.findFragmentById(R.id.fragment2))
                    .commit();
        }
    }


    @Override
    public void onItemSelected(int index) {

        tvdescription.setText(discription[index]);
        if (findViewById(R.id.portrait)!=null){
            FragmentManager manager = this.getSupportFragmentManager();
            manager.beginTransaction()
                    .hide(manager.findFragmentById(R.id.fragment))
                    .show(manager.findFragmentById(R.id.fragment2))
                    .addToBackStack(null)
                    .commit();
        }
    }
}
