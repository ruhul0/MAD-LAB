package com.example.sharedpreference;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView text1;
    EditText etext;
    Button btn1;
    String name;
    public static String PREF_NAME = "com.example.mysharedpreference";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences pref = getSharedPreferences(PREF_NAME,MODE_PRIVATE);
        name=pref.getString("user","");
        text1 = findViewById(R.id.text1);
        etext = findViewById(R.id.etext);
        btn1 = findViewById(R.id.btn1);
        text1.setText("Welcome "+name);
        System.out.println(name);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = etext.getText().toString();

                SharedPreferences.Editor editor = getSharedPreferences(PREF_NAME,MODE_PRIVATE).edit();
                editor.putString("user",name);
                editor.commit();
                text1.setText("Welcome "+name);
            }
        });
    }
}
